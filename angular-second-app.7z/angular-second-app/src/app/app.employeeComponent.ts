import { Component } from '@angular/core';

@Component({
    selector : '<emp-selector>',
    template : `<h1>{{empId}}</h1>
    <h2>{{empName}}</h2>
    <h3>{{desig}}</h3>`
    //templateUrl : `./app.employeecomponent.html`
})

export class EmployeeComponent{

    empId : number = 123;
    empName : string = "pavan";
    desig : string = "consultant";

}